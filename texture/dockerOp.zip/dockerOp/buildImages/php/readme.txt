just for test i created this dockerfile , you must put your's here , 
and please inlcude all the configuration for your image to work fine 