you are missing some configuration for the apache container.
please set them and then build your image.

and change the url for the mysql database to the  db container name .
docker create a dns record so you can access the db container by only the container name which is
in this case , db for mysql , and php for the php container , and web for the apache container


and then run docker-compose up  to build and start the application